import { Routes, Route, Navigate } from 'react-router-dom';
import { useIsAuthenticated } from './store/authStore';

import Login         from './pages/Login';
import Register      from './pages/Register';
import Dashboard     from './pages/Dashboard';
import Courses       from './pages/Courses';
import Skills        from './pages/Skills';
import Achievements  from './pages/Achievements';
import ProtectedRoute from './components/ProtectedRoute';
import Layout        from './components/Layout';

// Lazy placeholder for pages not yet fully built
function ComingSoon({ name }) {
  return (
    <div style={{ padding: 40, textAlign: 'center', color: '#64748b' }}>
      <div style={{ fontSize: 48, marginBottom: 16 }}>🚧</div>
      <h2 style={{ color: '#1e293b', marginBottom: 8 }}>{name}</h2>
      <p>Coming in Sprint 3 — back-end is ready, UI in progress.</p>
    </div>
  );
}

export default function App() {
  const isAuthenticated = useIsAuthenticated();

  return (
    <Routes>
      {/* Public */}
      <Route path="/login"
        element={isAuthenticated ? <Navigate to="/dashboard" replace /> : <Login />} />
      <Route path="/register"
        element={isAuthenticated ? <Navigate to="/dashboard" replace /> : <Register />} />

      {/* Protected — all inside Layout (sidebar + topbar) */}
      <Route element={<ProtectedRoute />}>
        <Route element={<Layout />}>
          <Route path="/dashboard"    element={<Dashboard />} />
          <Route path="/courses"      element={<Courses />} />
          <Route path="/skills"       element={<Skills />} />
          <Route path="/achievements" element={<Achievements />} />
          <Route path="/community"    element={<ComingSoon name="Community" />} />
          <Route path="/tutor"        element={<ComingSoon name="AI Tutor" />} />
          <Route path="/path"         element={<ComingSoon name="Learning Path" />} />
        </Route>
      </Route>

      <Route path="*"
        element={<Navigate to={isAuthenticated ? '/dashboard' : '/login'} replace />} />
    </Routes>
  );
}
